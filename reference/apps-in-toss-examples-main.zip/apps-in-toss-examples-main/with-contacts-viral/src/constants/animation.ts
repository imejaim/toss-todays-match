/**
 * 애니메이션 설정
 */
export const ANIMATION = {
  CELL_DELAY_MS: 70,
  HEART_DELAY_MS: 300,
} as const;
