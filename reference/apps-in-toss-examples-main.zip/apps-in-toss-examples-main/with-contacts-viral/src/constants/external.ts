/**
 * 친구 초대 모듈 ID
 */
export const CONTACTS_VIRAL_MODULE_ID = 'f15fcc7e-e2a8-4986-b08c-f65756078592';
