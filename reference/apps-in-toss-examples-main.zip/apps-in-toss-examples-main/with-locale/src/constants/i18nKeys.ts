export const makeLocaleKeys = (namespace: string) => ({
  title: `${namespace}.title`,
  description: `${namespace}.description`,
});
