import '@testing-library/react-native/extend-expect';
import { setup } from "@granite-js/react-native/jest";

setup({ rootDir: __filename });
