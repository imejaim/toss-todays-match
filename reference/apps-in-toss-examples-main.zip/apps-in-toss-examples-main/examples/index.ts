import { register } from "@granite-js/react-native";
import App from './src/_app';

register(App);
