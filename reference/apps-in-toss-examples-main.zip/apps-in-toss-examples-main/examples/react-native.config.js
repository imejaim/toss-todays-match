/* eslint-disable @typescript-eslint/no-require-imports */
/* eslint-disable @typescript-eslint/no-var-requires */
module.exports = {
  reactNativePath: require('path').dirname(require.resolve('react-native/package.json')),
};
