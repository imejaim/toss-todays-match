![apps-in-toss-examples-thumbnail-image](./assets/apps-in-toss-examples-thumbnail.png)

# Apps in Toss Examples

**Apps in Toss**는 토스 앱 안에 입점사의 서비스를 담을 수 있는 새로운 미니앱 생태계예요.  
이 레포지토리에는 **Apps in Toss** 개발에 참고할 수 있는 다양한 예시들이 담겨 있고, 예시 파일을 다운로드하면 바로 테스트해볼 수 있어요.  
더 자세한 내용은 각 예시 디렉토리에 있는 `README.md` 파일을 참고해 주세요.

<br />  
  
## 📌 참고사항

- [앱인토스 개발자센터](https://developers-apps-in-toss.toss.im/)
- [앱인토스 콘솔](https://apps-in-toss.toss.im/)
